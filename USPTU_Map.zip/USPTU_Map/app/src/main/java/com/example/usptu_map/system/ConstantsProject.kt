package com.example.usptu_map.system

object ConstantsProject {
    const val API_KEY_YANDEX_MAPS: String = "ea56030a-0248-44aa-8ff3-132754a2c4a8"

    const val INTENT_KEY1: String = "intent_key1"
    const val INTENT_KEY2: String = "intent_key2"
}