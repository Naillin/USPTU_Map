package com.example.usptu_map.map_operations.placemark_and_polygon

import com.yandex.mapkit.map.MapObject
import com.yandex.mapkit.map.PlacemarkMapObject
import com.yandex.mapkit.map.PolygonMapObject

interface SettingsPlacemarkPolygon{

    fun deleteMapObjects()

    //fun updatePolygonColor(polygonMapObject: PolygonMapObject, color: Int): PolygonMapObject
    //fun updatePolygonStrokeColor(polygonMapObject: PolygonMapObject, color: Int): PolygonMapObject
    //fun updatePolygonStrokeWidth(polygonMapObject: PolygonMapObject, width: Float): PolygonMapObject
    //fun updatePlacemarkIcon(placemarkMapObject: PlacemarkMapObject, iconResId: Int): PlacemarkMapObject


}