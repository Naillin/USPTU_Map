package com.example.usptu_map.project_objects.coordinates


object Departments {

    val firstBuildingDepartments = listOf(
        "Кафедра",
        "Кафедра",
        "Кафедра"
    )

    val secondBuildingDepartments = listOf(
        "Кафедра",
        "Кафедра",
        "Кафедра"
    )

    val thirdBuildingDepartments = listOf(
        "Кафедра",
        "Кафедра",
        "Кафедра"
    )

    val fourthBuildingDepartments = listOf(
        "Кафедра",
        "Кафедра",
        "Кафедра"
    )

    val sevenBuildingDepartments = listOf(
        "Кафедра",
        "Кафедра",
        "Кафедра"
    )

    val eightBuildingDepartments = listOf(
        "Кафедра",
        "Кафедра",
        "Кафедра"
    )

    val elevenBuildingDepartments = listOf(
        "Кафедра",
        "Кафедра",
        "Кафедра"
    )
}